const express = require('express');
const multer = require('multer');
const db = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

router.use(requireAuth);

router.post('/', async (req, res) => {
  try {
    const { name, industry, email, phone, notes } = req.body || {};
    if (!name || !String(name).trim()) return res.status(400).json({ error: 'Client name is required' });
    const result = await db.query(
      `INSERT INTO clients (name, industry, email, phone, notes, created_by)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, name, industry, email, phone, notes, created_at`,
      [name.trim(), industry || '', email || '', phone || '', notes || '', req.user.id]
    );
    res.status(201).json({ client: result.rows[0] });
  } catch (e) {
    console.error('create client error', e);
    res.status(500).json({ error: 'Could not create client' });
  }
});

router.patch('/:id', async (req, res) => {
  try {
    const fields = ['name', 'industry', 'email', 'phone', 'notes'];
    const sets = [];
    const values = [];
    fields.forEach((f) => {
      if (Object.prototype.hasOwnProperty.call(req.body, f)) {
        values.push(req.body[f]);
        sets.push(`${f} = $${values.length}`);
      }
    });
    if (sets.length === 0) return res.status(400).json({ error: 'No fields to update' });
    values.push(req.params.id);
    const result = await db.query(
      `UPDATE clients SET ${sets.join(', ')} WHERE id = $${values.length} RETURNING id, name, industry, email, phone, notes, created_at`,
      values
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Client not found' });
    res.json({ client: result.rows[0] });
  } catch (e) {
    console.error('update client error', e);
    res.status(500).json({ error: 'Could not update client' });
  }
});

router.delete('/:id', async (req, res) => {
  await db.query('DELETE FROM clients WHERE id = $1', [req.params.id]);
  res.json({ ok: true });
});

router.put('/:id/photo', upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No photo uploaded' });
    if (!/^image\//.test(req.file.mimetype)) return res.status(400).json({ error: 'File must be an image' });
    await db.query('UPDATE clients SET photo_data = $1, photo_mime_type = $2 WHERE id = $3', [req.file.buffer, req.file.mimetype, req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('upload photo error', e);
    res.status(500).json({ error: 'Could not upload photo' });
  }
});

router.get('/:id/photo', async (req, res) => {
  const result = await db.query('SELECT photo_data, photo_mime_type FROM clients WHERE id = $1', [req.params.id]);
  if (result.rows.length === 0 || !result.rows[0].photo_data) return res.status(404).end();
  res.set('Content-Type', result.rows[0].photo_mime_type || 'image/jpeg');
  res.set('Cache-Control', 'private, max-age=3600');
  res.send(result.rows[0].photo_data);
});

router.delete('/:id/photo', async (req, res) => {
  await db.query('UPDATE clients SET photo_data = NULL, photo_mime_type = NULL WHERE id = $1', [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
