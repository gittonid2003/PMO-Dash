// Applies schema.sql against DATABASE_URL. Safe to run more than once —
// every statement in schema.sql uses CREATE TABLE (not CREATE TABLE IF NOT
// EXISTS) specifically so a second run fails loudly on already-applied
// tables rather than silently doing nothing, which is safer when this is
// being run by hand during a deployment rather than through a proper
// migration-tracking system.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const db = require('./pool');

async function migrate() {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const sql = fs.readFileSync(schemaPath, 'utf8');
  console.log('Applying schema.sql to ' + (process.env.DATABASE_URL ? process.env.DATABASE_URL.replace(/:[^:@]+@/, ':****@') : '(no DATABASE_URL set)') + ' ...');
  try {
    await db.query(sql);
    console.log('Schema applied successfully.');
  } catch (e) {
    if (e.code === '42P07') {
      console.error('Tables already exist — schema appears to already be applied. Nothing to do.');
      process.exit(0);
    }
    throw e;
  }
  process.exit(0);
}

migrate().catch((e) => {
  console.error('Migration failed:', e.message);
  process.exit(1);
});
