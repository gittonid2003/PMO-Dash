const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // Most hosted Postgres providers (Render, Railway, Supabase, etc.)
  // require SSL but use a certificate not in Node's default trust
  // store; rejectUnauthorized:false is the standard, safe-enough
  // pattern for this (the connection is still encrypted, just not
  // validated against a CA) unless the provider gives you their own
  // CA cert to pin.
  ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false }
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle database client', err);
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  getClient: () => pool.connect(),
  pool
};
