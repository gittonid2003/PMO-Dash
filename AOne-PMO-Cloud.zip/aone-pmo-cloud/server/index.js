require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');

const authRoutes = require('./routes/auth');
const clientRoutes = require('./routes/clients');
const { router: projectRoutes } = require('./routes/projects');
const documentRoutes = require('./routes/documents');
const { router: workspaceRoutes } = require('./routes/workspace');
const dataRoutes = require('./routes/data');

const app = express();
const PORT = process.env.PORT || 3000;

// Trust the first proxy hop (Render/Railway/Fly/etc. all sit behind one) --
// needed for rate limiting and secure cookies to see the real client IP
// and scheme rather than the proxy's.
app.set('trust proxy', 1);

app.use(cors({
  origin: process.env.CORS_ORIGIN || true,
  credentials: true
}));
app.use(cookieParser());
app.use(express.json({ limit: '2mb' })); // file uploads use multipart, not JSON, so this stays small

// A generous, app-wide ceiling in case something upstream misbehaves --
// the real, tight limit for login attempts specifically lives in
// routes/auth.js.
app.use(rateLimit({ windowMs: 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));

app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'SAMEORIGIN');
  res.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  // 'unsafe-inline' on style-src only (for the few inline style="" attributes
  // the UI sets dynamically, e.g. accent colors) -- script-src stays strict,
  // no inline or eval'd script anywhere in this app.
  res.set('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'");
  next();
});

app.use('/api/auth', authRoutes);
app.use('/api/clients', clientRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/projects', documentRoutes); // documents nest under /api/projects/:projectId/documents
app.use('/api/workspace', workspaceRoutes);
app.use('/api/data', dataRoutes);

app.get('/api/health', (req, res) => res.json({ ok: true }));

// Serve the web frontend from the same service -- one deployment for the
// whole app, no separate frontend hosting or CORS setup needed in
// production.
const WEB_DIR = path.join(__dirname, '..', 'web', 'dist');
app.use(express.static(WEB_DIR));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(WEB_DIR, 'index.html'));
});

app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Something went wrong' });
});

app.listen(PORT, () => {
  console.log(`AOne PMO server listening on port ${PORT}`);
});
